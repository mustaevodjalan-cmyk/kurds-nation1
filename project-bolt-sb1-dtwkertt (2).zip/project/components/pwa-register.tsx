'use client';

import { useEffect } from 'react';

export function PwaRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production' || !('serviceWorker' in navigator)) {
      return;
    }

    navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).catch((error) => {
      console.error('Service worker registration failed:', error);
    });
  }, []);

  return null;
}
